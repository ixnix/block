Contact Xin Xi (xinxi@mtu.edu) if you have questions and comments.

1. s1_calculate_vapv.py
Step 1 - calculate the vertically averaged potential voricity based on ERA5 pressure level data (in years files).

2. s2_padding_vapv.py
Step 2 - add padding to the beginning and end of each yearly files in order to detect blocking events crossing two years.

3. s3_calculate_clim.py
Step 3 - calculate the daily climatological VAPV.

4. s4_calculate_anom.py
Step 4 - calculate the VAPV anomlies from the climatological average.

5. s5_calculate_threshold.py
Step 5 - calculate the 0.1 quantile of daily VAPV anomalies as the threshold for blocking detection. 

6. s6_calculate_block.py
Step 6 - detect areas with negative VAPV anomalies below the threshold, with 70% overlap between successive time steps for at least 5 days.

7. contrack.py
This script contains the modules and functions used in the above steps.
Developed by Daniel Steinfeld (daniel.steinfeld@alumni.ethz.ch)
