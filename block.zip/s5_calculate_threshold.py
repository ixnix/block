import os
import glob
import sys
import contrack
import numpy as np
import xarray as xr
import pandas as pd
from datetime import date, datetime, timedelta
from numpy.core import datetime64
import matplotlib.pyplot as plt
# logs and warning
import logging
import warnings
warnings.filterwarnings("ignore")

yrBgn = 1959
yrEnd = 2000
files = sorted(sum([ glob.glob('Anom/VAPVA_{:d}.nc'.format(yr)) for yr in np.arange(yrBgn,yrEnd+1,dtype='int') ],[]))
print(files)

#ds = xr.open_mfdataset(files)#,parallel=True)
#ds = ds.chunk({"time":len(ds.time)})
##ds = ds.sel(latitude=slice(90,0)) 
#print('ds size in GB {:0.2f}\n'.format(ds.nbytes / 1e9))
#print(ds.keys())
#threshold = ds['anom'].sel(latitude=slice(90,30)).groupby(ds.time.dt.dayofyear).quantile(0.1, dim=("time", "longitude", "latitude"))


ds = xr.open_mfdataset(files,parallel=True)
print('ds size in GB {:0.2f}\n'.format(ds.nbytes / 1e9))
print(ds.keys())
ds = ds.sel(latitude=slice(90,0))
threshold = ds['anom'].chunk(dict(time=-1)).sel(latitude=slice(90,30)).groupby(ds.time.dt.dayofyear).quantile(0.1, dim=("time", "longitude", "latitude"))
rft = np.fft.rfft(threshold.values)
rft[5:] = 0   # Note, rft.shape = 21
threshold_fft = np.fft.irfft(rft)


threshold.plot(label='0.1 quantile')
plt.plot(threshold_fft, label='FFT')
plt.legend()
plt.savefig('Thres/threshold_30-90.png',dpi=300)


threshold.values = threshold_fft
threshold.to_netcdf('Thres/vapv_threshold_dayofyear_30-90.nc')
