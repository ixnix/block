import os
import glob
import numpy as np
import xarray as xr
import pandas as pd
import time
import contrack
# logs and warning
import logging
import warnings
warnings.filterwarnings("ignore")

yrBgn = 1959
yrEnd = 2023
years = np.arange(yrBgn,yrEnd+1,1,dtype='int')

# load threshold
threshold = xr.open_dataset('Thres/vapv_threshold_dayofyear_30-90.nc')
threshold = threshold['anom'].reset_coords(['quantile'], drop=True)
print(threshold)

for iy, yr in enumerate(years):
    print(yr)
    # initiate contrack
    block = contrack.contrack()

    # read ERA5
    block.read('Anom/VAPVA_{}.nc'.format(yr))

    # remove SH
    #block.ds = block.ds.sel(latitude=slice(90,0))

    # calculate blocking
    block.run_contrack(variable='anom', 
                      threshold=threshold,
                      gorl='<=',
                      overlap=0.7,
                      persistence=5*4, # 5 day
                      twosided=True)

    # track lifecycle of blocks
    block_df = block.run_lifecycle(flag='flag', variable='anom')

    # save to disk
    block_df.to_csv('Block/Blocks_lifecycle_{}.csv'.format(yr),index=False)
    block['flag'].to_netcdf('Block/Blocks_{}.nc'.format(yr))