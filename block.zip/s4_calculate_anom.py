import sys
import contrack
import numpy as np
import xarray as xr
import pandas as pd
from datetime import date, timedelta
from numpy.core import datetime64
import logging
import warnings
warnings.filterwarnings("ignore")


start_date = date(2001,1,1)
end_date   = date(2023,12,31)
delta      = end_date.year - start_date.year

## read 31-day running mean climatology.
clim = xr.open_dataset('Clim/vapv_climatology.nc')

## For SH, pv is multiplied by -1
clim = xr.where(clim.latitude>=0,clim,-1*clim,keep_attrs=True)

## remove SH
#clim = clim.sel(latitude=slice(90,0))

for i in range(delta + 1):
    year = start_date.year+i
    print(year)

    ## initiate contrack
    block = contrack.contrack()
    
    ## read ERA5
    block.read('VAPV/0.5deg_6hrly_pad/vapv_{:d}.nc'.format(year))
    #print(block)

    ## remove SH
    #block.ds = block.ds.sel(latitude=slice(90,0)) 

    ## For SH, pv is multiplied by -1
    block.ds = xr.where(block.ds.latitude>=0,block.ds,-1*block.ds,keep_attrs=True)
    
    # calc VAPV anom
    block.calc_anom(variable="pv",
                    smooth=8, # needs to be in timesteps: 6h*8 = 2-days
                    window=31, # needs to be in dayofyear: 31 days. 
                    groupby="dayofyear",
                    clim=clim.pv)

    ## remove addition days at start and end
    block.ds = block.ds.sel(time=block.ds.time.dt.year==year)
    
    ## save each year as separate file
    block['anom'].to_netcdf('Anom/VAPVA_{}.nc'.format(year))
    #print(year)
