import contrack
import glob
import numpy as np
import xarray as xr
import pandas as pd
from datetime import date, timedelta
from numpy.core import datetime64
import logging
import warnings
warnings.filterwarnings("ignore")


# calculate daily climatology based on 1959-2000
yrBgn = 1959
yrEnd = 2000
files = sum([ glob.glob('VAPV/0.5deg_6hrly/vapv_{}.nc'.format(yr)) for yr in np.arange(yrBgn,yrEnd+1)],[])
files = sorted(files)
print(files)

ds = xr.open_mfdataset(files,parallel=True)
print(ds)

# initiate contrack
block = contrack.contrack()

# read the existing ds
block.read_xarray(ds)

block.set_up(
            time_name='time',
            longitude_name='longitude',
            latitude_name='latitude',
)

# calculate climatology
clim = block.calc_clim(variable='pv',
                       window=31,
                       groupby='dayofyear',
                      )

ds_clim = clim.to_dataset()
ds_clim['pv'] = ds_clim['pv'].assign_attrs(units='PVU',long_name='Potential vorticity')

comp = dict(zlib=True, complevel=6)
encoding = {var: comp for var in ds_clim.data_vars}
ds_clim.to_netcdf('Clim/vapv_climatology.nc')
