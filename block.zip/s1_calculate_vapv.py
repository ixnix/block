import os
import glob
import numpy as np
import xarray as xr
import pandas as pd
import time

xr.set_options(keep_attrs=True)

def make_sure_path_exists(path):
    try:
        os.makedirs(path)
    except OSError as exception:
        if exception.errno != errno.EEXIST:
            raise

reso = 0.5
indir = 'PV/{}deg/'.format(reso)
outdir = 'VAPV/{}deg_6hrly/'.format(reso)
yrBgn = 2023
yrEnd = 2023
years = np.arange(yrBgn,yrEnd+1,1,dtype='int')
for iy, yr in enumerate(years):
    print(yr)
    # get the start time
    st = time.time()
    
    ds = xr.open_dataset(indir+'pres_pv_{:d}.nc'.format(yr))
    ds2 = ds.mean(dim='level')*10**6
    ds2['pv'] = ds2['pv'].assign_attrs(units='pvu')

    #savedir = '0.5deg/{:d}'.format(yr)
    #make_sure_path_exists(savedir)

    comp = dict(zlib=True, complevel=6)
    encoding = {var: comp for var in ds2.data_vars}
    ds2.to_netcdf(outdir+'vapv_{:d}.nc'.format(yr),encoding=encoding)
    
    # get the end time
    et = time.time()
    # get the execution time
    elapsed_time = et - st
    print('Execution time:', elapsed_time, 'seconds')

