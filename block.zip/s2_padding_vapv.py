import os
import glob
import numpy as np
import xarray as xr
import pandas as pd
import time
import logging
import warnings
warnings.filterwarnings("ignore")


indir  = 'VAPV/0.5deg_6hrly/'
outdir = 'VAPV/0.5deg_6hrly_pad/'
yrBgn  = 2023
yrEnd  = 2023
ndPad  = 10 # number of dats padding to VAPV files
years  = np.arange(yrBgn,yrEnd+1,1,dtype='int')

for iy, yr in enumerate(years):
    previous_file = glob.glob(indir+'vapv_{}.nc'.format(yr-1))
    next_file     = glob.glob(indir+'vapv_{}.nc'.format(yr+1))

    if len(previous_file)==0 and len(next_file)!=0 :
        #print('either the previous or next file does not exist')
        ds2 = xr.open_dataset(indir+'vapv_{}.nc'.format(yr))
        ds3 = xr.open_dataset(indir+'vapv_{}.nc'.format(yr+1))
        ds3sub = ds3.sel(time=slice('{}-1-1'.format(yr+1), '{}-1-{}'.format(yr+1,ndPad)))
        ds_new = xr.concat([ds2,ds3sub],dim='time')
        
        comp = dict(zlib=True,complevel=6)
        encoding = {var: comp for var in ds_new.data_vars}
        ds_new.to_netcdf(outdir+'vapv_{}.nc'.format(yr),encoding=encoding)
    
    elif len(previous_file)!=0 and len(next_file)==0:
        ds1 = xr.open_dataset(indir+'vapv_{}.nc'.format(yr-1))
        ds2 = xr.open_dataset(indir+'vapv_{}.nc'.format(yr))
        ds1sub = ds1.sel(time=slice('{}-12-{}'.format(31-ndPad,yr-1), '{}-12-31'.format(yr-1)))
        ds_new = xr.concat([ds1sub,ds2],dim='time')
        
        comp = dict(zlib=True,complevel=6)
        encoding = {var: comp for var in ds_new.data_vars}
        ds_new.to_netcdf(outdir+'vapv_{:d}.nc'.format(yr),encoding=encoding)

    else:
        ds1 = xr.open_dataset(indir+'vapv_{}.nc'.format(yr-1))
        ds2 = xr.open_dataset(indir+'vapv_{}.nc'.format(yr))
        ds3 = xr.open_dataset(indir+'vapv_{}.nc'.format(yr+1))
        ds1sub = ds1.sel(time=slice('{}-12-{}'.format(31-ndPad,yr-1), '{}-12-31'.format(yr-1)))
        ds3sub = ds3.sel(time=slice('{}-1-1'.format(yr+1), '{}-1-{}'.format(yr+1,ndPad)))
        
        ds_new = xr.concat([ds1sub,ds2,ds3sub],dim='time')
        comp = dict(zlib=True,complevel=6)
        encoding = {var: comp for var in ds_new.data_vars}
        ds_new.to_netcdf(outdir+'vapv_{:d}.nc'.format(yr),encoding=encoding)

        # get the end time
        #et = time.time()
        # get the execution time
        #elapsed_time = et - st
        #print('Execution time:', elapsed_time, 'seconds')
